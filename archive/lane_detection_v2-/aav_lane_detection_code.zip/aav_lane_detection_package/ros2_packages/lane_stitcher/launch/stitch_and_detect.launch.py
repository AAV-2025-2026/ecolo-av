#!/usr/bin/env python3
"""
stitch_and_detect.launch.py  —  lane_stitcher package  [UPDATED]
═══════════════════════════════════════════════════════════════════
Updated to include topic_bridge node that maps:
  /aav/cam1/image_raw  →  /cam_left/image_raw
  /aav/cam2/image_raw  →  /cam_right/image_raw

This means the launch file now works with your existing camera
system (camera_decoder_node) without any changes to image_stitcher.

Usage — live cameras:
  ros2 launch lane_stitcher stitch_and_detect.launch.py

Usage — bag playback (same command, bridge handles remapping):
  ros2 bag play <bag_path>
  ros2 launch lane_stitcher stitch_and_detect.launch.py

Usage — custom topic names:
  ros2 launch lane_stitcher stitch_and_detect.launch.py \
      cam1_topic:=/aav/cam1/image_raw \
      cam2_topic:=/aav/cam2/image_raw
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg = get_package_share_directory('lane_stitcher')

    # ── Launch arguments ──────────────────────────────────────────
    cam1_topic_arg = DeclareLaunchArgument(
        'cam1_topic',
        default_value='/aav/cam1/image_raw',
        description='Source topic for camera 1 (left)'
    )
    cam2_topic_arg = DeclareLaunchArgument(
        'cam2_topic',
        default_value='/aav/cam2/image_raw',
        description='Source topic for camera 2 (right)'
    )

    # ── Node 1: Topic Bridge ──────────────────────────────────────
    # Maps /aav/cam1 → /cam_left  and  /aav/cam2 → /cam_right
    # Works for live cameras AND bag playback — same command
    topic_bridge_node = Node(
        package='lane_stitcher',
        executable='topic_bridge',
        name='topic_bridge',
        parameters=[{
            'cam1_src': LaunchConfiguration('cam1_topic'),
            'cam2_src': LaunchConfiguration('cam2_topic'),
            'cam_left_dst':  '/cam_left/image_raw',
            'cam_right_dst': '/cam_right/image_raw',
        }],
        output='screen',
    )

    # ── Node 2: Image Stitcher ────────────────────────────────────
    # Undistorts, warps to BEV, feather blends
    # Subscribes to /cam_left and /cam_right (provided by bridge above)
    image_stitcher_node = Node(
        package='lane_stitcher',
        executable='image_stitcher',
        name='image_stitcher',
        output='screen',
    )

    # ── Node 3: Dt-Pham Lane Detector ────────────────────────────
    # Multi-feature thresholding + LaneLines fitting
    # Requires: export LANE_REPO=~/Advanced-Lane-Lines
    dt_pham_wrapper_node = Node(
        package='lane_stitcher',
        executable='dt_pham_wrapper',
        name='dt_pham_wrapper',
        output='screen',
        env={'LANE_REPO': os.environ.get(
            'LANE_REPO',
            os.path.expanduser('~/Advanced-Lane-Lines')
        )},
    )

    return LaunchDescription([
        cam1_topic_arg,
        cam2_topic_arg,
        topic_bridge_node,
        image_stitcher_node,
        dt_pham_wrapper_node,
    ])
