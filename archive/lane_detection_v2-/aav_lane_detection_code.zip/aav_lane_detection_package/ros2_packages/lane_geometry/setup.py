from setuptools import setup
import os
from glob import glob

package_name = 'lane_geometry'

setup(
    name=package_name,
    version='2.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    entry_points={
        'console_scripts': [
            'lane_geometry_node = lane_geometry.lane_geometry_node:main',
            'control_interface  = lane_geometry.control_interface:main',
            'geometry_logger    = lane_geometry.geometry_logger:main',
        ],
    },
)
