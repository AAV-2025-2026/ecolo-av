"""
geometry.launch.py  —  lane_geometry package
═══════════════════════════════════════════════════════════════════
Launches Stage 4 + 5 + 6 of the pipeline:
  Geometry extraction → Control → Logger

Run AFTER stitch_and_detect.launch.py is running and
/lane_mask_unified is being published.

Usage:
  ros2 launch lane_geometry geometry.launch.py

  # With calibrated pixel scale (run pixel_scale_calibrator.py first):
  ros2 launch lane_geometry geometry.launch.py \
      metres_per_pixel_x:=0.01823 metres_per_pixel_y:=0.02341

  # Disable logging:
  ros2 launch lane_geometry geometry.launch.py enable_logging:=false

  # Slow speed for testing:
  ros2 launch lane_geometry geometry.launch.py base_speed:=1.0
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        # ── Tunable parameters ───────────────────────────────────────
        DeclareLaunchArgument('metres_per_pixel_x', default_value='0.020'),
        DeclareLaunchArgument('metres_per_pixel_y', default_value='0.025'),
        DeclareLaunchArgument('base_speed',         default_value='2.0'),
        DeclareLaunchArgument('steering_gain',      default_value='0.8'),
        DeclareLaunchArgument('enable_logging',     default_value='true'),

        # ── Stage 4: Geometry extraction ─────────────────────────────
        Node(
            package    = 'lane_geometry',
            executable = 'lane_geometry_node',
            name       = 'lane_geometry_node',
            output     = 'screen',
            parameters = [{
                'metres_per_pixel_x': LaunchConfiguration('metres_per_pixel_x'),
                'metres_per_pixel_y': LaunchConfiguration('metres_per_pixel_y'),
                'steering_gain':      LaunchConfiguration('steering_gain'),
            }]
        ),

        # ── Stage 5: Control ─────────────────────────────────────────
        Node(
            package    = 'lane_geometry',
            executable = 'control_interface',
            name       = 'control_interface',
            output     = 'screen',
            parameters = [{
                'base_speed_mps': LaunchConfiguration('base_speed'),
            }]
        ),

        # ── Stage 6: Logger (optional) ───────────────────────────────
        Node(
            package    = 'lane_geometry',
            executable = 'geometry_logger',
            name       = 'geometry_logger',
            output     = 'screen',
            condition  = IfCondition(LaunchConfiguration('enable_logging')),
        ),
    ])
