# AAV Lane Detection — Code Package

## Contents

```
ros2_packages/          Full ROS2 Humble package set (deploy on Jetson)
  lane_stitcher/
    src/
      topic_bridge.py         Topic remapping node
      camera_publisher.py     RTSP camera decoder
      image_stitcher.py       Fisheye undistort + BEV warp + blend
      dt_pham_wrapper.py      Improved thresholding (FIX 1,2,7)
      homography_calibrator.py  Homography calibration tool
    config/homography.yaml
    launch/stitch_and_detect.launch.py

  lane_geometry/
    src/
      lane_geometry_node.py   Sliding window + polyfit + smoothing (FIX 3,4,6)
      control_interface.py    PID + state machine (NEW)
      geometry_logger.py      CSV geometry logger
    msg/LaneGeometry.msg
    launch/geometry.launch.py

standalone/             No ROS2 needed — just Python + OpenCV
  lane_pipeline.py      Full pipeline on any video file
  run_dtpham.py         Original Dt-Pham wrapper for any video

diagrams/
  uml_class_diagram.svg
  state_machine_diagram.svg
```

## Quick Start — Standalone (no ROS2)

```bash
pip3 install opencv-python numpy
python3 standalone/lane_pipeline.py --video /path/to/dashcam.mp4 --crop_top 0.30
```

## Quick Start — ROS2 on Jetson

```bash
cd ~/ros2_ws/src
cp -r ros2_packages/lane_stitcher .
cp -r ros2_packages/lane_geometry .
cd ~/ros2_ws && colcon build
source install/setup.bash
ros2 launch lane_stitcher stitch_and_detect.launch.py
ros2 launch lane_geometry geometry.launch.py
```

## Key Topics
| Topic | Direction | Content |
|---|---|---|
| /bev_unified | stitcher → wrapper | BEV image 1200×500 |
| /lane_mask_unified | wrapper → geometry | Binary lane mask |
| /lane_geometry | geometry → control | Curvature, offset, width |
| /control_cmd | control → vehicle | Twist steering command |
